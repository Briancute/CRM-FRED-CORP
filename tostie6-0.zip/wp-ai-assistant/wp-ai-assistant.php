<?php
/*
Plugin Name: Berry
Plugin URI: https://your-plugin-url.com
Description: Advanced AI Integration for customer support, email automation, and on-site interactions
Version: 1.0.0
Author: Your Name
License: GPL v2 or later
Text Domain: wp-ai-assistant
*/

// If this file is called directly, abort
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('WPAI_VERSION', '1.0.0');
define('WPAI_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPAI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPAI_SETTINGS_KEY', 'wpai_settings');

// Main plugin class
class WPAI_Plugin {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Register hooks
        add_action('plugins_loaded', array($this, 'init'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        register_activation_hook(__FILE__, array($this, 'activate'));
    }
    
    public function init() {
        // Load required files
        $required_files = array(
            'includes/class-ai-chat.php',
            'includes/class-email-automation.php',
            'includes/class-customer-support.php',
            'includes/class-assistant-manager.php',
            'includes/class-assistant-validator.php',
            'includes/class-assistant-tester.php',
            'admin/admin-settings.php',
            'admin/admin-dashboard.php',
            'admin/create-assistant.php',
            'admin/test-system.php'
        );

        foreach ($required_files as $file) {
            $file_path = WPAI_PLUGIN_DIR . $file;
            if (file_exists($file_path)) {
                require_once $file_path;
            }
        }

        // Initialize classes
        if (is_admin()) {
            WPAI_Assistant_Manager::get_instance();
        }
        new WPAI_Chat();
        new WPAI_Email_Automation();
        new WPAI_Customer_Support();
    }
    
    public function activate() {
        try {
            // Set default settings
            $default_settings = array(
                'openai_api_key' => '',
                'enable_chat' => true,
                'enable_email' => true,
                'enable_support' => true,
                'chat_initial_message' => 'Hi, My name is Berry',
                'model' => 'gpt-3.5-turbo'
            );
            
            if (!get_option(WPAI_SETTINGS_KEY)) {
                add_option(WPAI_SETTINGS_KEY, $default_settings);
            }

            // Create database tables
            if (class_exists('WPAI_Assistant_Manager')) {
                $assistant_manager = WPAI_Assistant_Manager::get_instance();
                $assistant_manager->create_tables();
            }
        } catch (Exception $e) {
            error_log('Berry AI Plugin Activation Error: ' . $e->getMessage());
            error_log('Error trace: ' . $e->getTraceAsString());
            wp_die('Error activating Berry AI plugin: ' . esc_html($e->getMessage()));
        }
    }
    
    public function admin_menu() {
        add_menu_page(
            'Berry AI Assistant',
            'Berry AI',
            'manage_options',
            'wpai-dashboard',
            'wpai_render_dashboard_page',
            'dashicons-superhero',
            30
        );

        // Add submenu pages
        $submenus = array(
            array(
                'page_title' => 'Dashboard',
                'menu_title' => 'Dashboard',
                'capability' => 'manage_options',
                'menu_slug'  => 'wpai-dashboard',
                'function'   => 'wpai_render_dashboard_page'
            ),
            array(
                'page_title' => 'Create Assistant',
                'menu_title' => 'Create Assistant',
                'capability' => 'manage_options',
                'menu_slug'  => 'wpai-create-assistant',
                'function'   => 'wpai_render_create_assistant_page'
            ),
            array(
                'page_title' => 'Settings',
                'menu_title' => 'Settings',
                'capability' => 'manage_options',
                'menu_slug'  => 'wpai-settings',
                'function'   => 'wpai_render_settings_page'
            )
        );

        if (defined('WP_DEBUG') && WP_DEBUG) {
            $submenus[] = array(
                'page_title' => 'System Tests',
                'menu_title' => 'System Tests',
                'capability' => 'manage_options',
                'menu_slug'  => 'wpai-system-tests',
                'function'   => 'wpai_render_test_page'
            );
        }

        foreach ($submenus as $submenu) {
            add_submenu_page(
                'wpai-dashboard',
                $submenu['page_title'],
                $submenu['menu_title'],
                $submenu['capability'],
                $submenu['menu_slug'],
                $submenu['function']
            );
        }
    }
    
    public function enqueue_scripts() {
        wp_enqueue_style('wpai-styles', WPAI_PLUGIN_URL . 'assets/css/style.css', array(), WPAI_VERSION);
        wp_enqueue_script('wpai-script', WPAI_PLUGIN_URL . 'assets/js/ai-assistant.js', array('jquery'), WPAI_VERSION, true);
        
        wp_localize_script('wpai-script', 'wpai_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpai-nonce'),
            'initial_message' => get_option(WPAI_SETTINGS_KEY)['chat_initial_message']
        ));
    }
    
    public function admin_enqueue_scripts($hook) {
        if ('settings_page_wp-ai-assistant' !== $hook) {
            return;
        }
        wp_enqueue_style('wpai-admin-styles', WPAI_PLUGIN_URL . 'assets/css/admin.css', array(), WPAI_VERSION);
    }
}

// Initialize the plugin
WPAI_Plugin::get_instance();
    exit;
}

// Define plugin constants
define('WPAI_VERSION', '1.0.0');
define('WPAI_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPAI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPAI_SETTINGS_KEY', 'wpai_settings');

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WPAI_VERSION', '1.0.0');
define('WPAI_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPAI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPAI_SETTINGS_KEY', 'wpai_settings');

// Load required files
require_once WPAI_PLUGIN_DIR . 'includes/class-ai-chat.php';
require_once WPAI_PLUGIN_DIR . 'includes/class-email-automation.php';
require_once WPAI_PLUGIN_DIR . 'includes/class-customer-support.php';
require_once WPAI_PLUGIN_DIR . 'includes/class-assistant-manager.php';
require_once WPAI_PLUGIN_DIR . 'includes/class-assistant-validator.php';
require_once WPAI_PLUGIN_DIR . 'includes/class-assistant-tester.php';
require_once WPAI_PLUGIN_DIR . 'admin/admin-settings.php';
require_once WPAI_PLUGIN_DIR . 'admin/admin-dashboard.php';
require_once WPAI_PLUGIN_DIR . 'admin/create-assistant.php';
require_once WPAI_PLUGIN_DIR . 'admin/test-system.php';

/**
 * Plugin initialization
 */
function wpai_init() {
    // Initialize the Assistant Manager first
    if (is_admin()) {
        WPAI_Assistant_Manager::get_instance();
    }

    // Initialize other classes
    new WPAI_Chat();
    new WPAI_Email_Automation();
    new WPAI_Customer_Support();
}

/**
 * Plugin activation
 */
function wpai_activate() {
    try {
        // Set default settings
        $default_settings = array(
            'openai_api_key' => '',
            'enable_chat' => true,
            'enable_email' => true,
            'enable_support' => true,
            'chat_initial_message' => 'Hi, My name is Berry',
            'model' => 'gpt-3.5-turbo'
        );
        
        if (!get_option(WPAI_SETTINGS_KEY)) {
            add_option(WPAI_SETTINGS_KEY, $default_settings);
        }

        // Create database tables
        $assistant_manager = WPAI_Assistant_Manager::get_instance();
        $assistant_manager->create_tables();
    } catch (Exception $e) {
        error_log('Berry AI Plugin Activation Error: ' . $e->getMessage());
        error_log('Error trace: ' . $e->getTraceAsString());
        wp_die('Error activating Berry AI plugin: ' . esc_html($e->getMessage()));
    }
}

/**
 * Register admin menu
 */
function wpai_admin_menu() {
    // Add main menu
    add_menu_page(
        'Berry AI Assistant',
        'Berry AI',
        'manage_options',
        'wpai-dashboard',
        'wpai_render_dashboard_page',
        'dashicons-superhero',
        30
    );

    // Add submenu pages
    $submenus = array(
        array(
            'page_title' => 'Dashboard',
            'menu_title' => 'Dashboard',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-dashboard',
            'function'   => 'wpai_render_dashboard_page'
        ),
        array(
            'page_title' => 'Create Assistant',
            'menu_title' => 'Create Assistant',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-create-assistant',
            'function'   => 'wpai_render_create_assistant_page'
        ),
        array(
            'page_title' => 'Settings',
            'menu_title' => 'Settings',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-settings',
            'function'   => 'wpai_render_settings_page'
        )
    );

    // Add system tests page if WP_DEBUG is enabled
    if (defined('WP_DEBUG') && WP_DEBUG) {
        $submenus[] = array(
            'page_title' => 'System Tests',
            'menu_title' => 'System Tests',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-system-tests',
            'function'   => 'wpai_render_test_page'
        );
    }

    // Register all submenu pages
    foreach ($submenus as $submenu) {
        add_submenu_page(
            'wpai-dashboard',
            $submenu['page_title'],
            $submenu['menu_title'],
            $submenu['capability'],
            $submenu['menu_slug'],
            $submenu['function']
        );
    }
}

/**
 * Enqueue frontend scripts
 */
function wpai_enqueue_scripts() {
    wp_enqueue_style('wpai-styles', WPAI_PLUGIN_URL . 'assets/css/style.css', array(), WPAI_VERSION);
    wp_enqueue_script('wpai-script', WPAI_PLUGIN_URL . 'assets/js/ai-assistant.js', array('jquery'), WPAI_VERSION, true);
    
    // Add localization for AJAX
    wp_localize_script('wpai-script', 'wpai_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('wpai-nonce'),
        'initial_message' => get_option(WPAI_SETTINGS_KEY)['chat_initial_message']
    ));
}

/**
 * Enqueue admin scripts
 */
function wpai_admin_enqueue_scripts($hook) {
    if ('settings_page_wp-ai-assistant' !== $hook) {
        return;
    }
    
    wp_enqueue_style('wpai-admin-styles', WPAI_PLUGIN_URL . 'assets/css/admin.css', array(), WPAI_VERSION);
}

// Register hooks
register_activation_hook(__FILE__, 'wpai_activate');
add_action('plugins_loaded', 'wpai_init');
add_action('admin_menu', 'wpai_admin_menu');
add_action('wp_enqueue_scripts', 'wpai_enqueue_scripts');
add_action('admin_enqueue_scripts', 'wpai_admin_enqueue_scripts');

/**
 * Plugin initialization
 */
function wpai_init() {
    // Initialize the Assistant Manager first
    if (is_admin()) {
        WPAI_Assistant_Manager::get_instance();
    }

    // Initialize other classes
    new WPAI_Chat();
    new WPAI_Email_Automation();
    new WPAI_Customer_Support();
}

/**
 * Plugin activation
 */
function wpai_activate() {
    try {
        // Set default settings
        $default_settings = array(
            'openai_api_key' => '',
            'enable_chat' => true,
            'enable_email' => true,
            'enable_support' => true,
            'chat_initial_message' => 'Hi, My name is Berry',
            'model' => 'gpt-3.5-turbo'
        );
        
        if (!get_option(WPAI_SETTINGS_KEY)) {
            add_option(WPAI_SETTINGS_KEY, $default_settings);
        }

        // Create database tables
        $assistant_manager = WPAI_Assistant_Manager::get_instance();
        $assistant_manager->create_tables();
    } catch (Exception $e) {
        error_log('Berry AI Plugin Activation Error: ' . $e->getMessage());
        error_log('Error trace: ' . $e->getTraceAsString());
        wp_die('Error activating Berry AI plugin: ' . esc_html($e->getMessage()));
    }
}

/**
 * Register admin menu
 */
function wpai_admin_menu() {
    // Add main menu
    add_menu_page(
        'Berry AI Assistant',
        'Berry AI',
        'manage_options',
        'wpai-dashboard',
        'wpai_render_dashboard_page',
        'dashicons-superhero',
        30
    );

    // Add submenu pages
    $submenus = array(
        array(
            'page_title' => 'Dashboard',
            'menu_title' => 'Dashboard',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-dashboard',
            'function'   => 'wpai_render_dashboard_page'
        ),
        array(
            'page_title' => 'Create Assistant',
            'menu_title' => 'Create Assistant',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-create-assistant',
            'function'   => 'wpai_render_create_assistant_page'
        ),
        array(
            'page_title' => 'Settings',
            'menu_title' => 'Settings',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-settings',
            'function'   => 'wpai_render_settings_page'
        )
    );

    // Add system tests page if WP_DEBUG is enabled
    if (defined('WP_DEBUG') && WP_DEBUG) {
        $submenus[] = array(
            'page_title' => 'System Tests',
            'menu_title' => 'System Tests',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-system-tests',
            'function'   => 'wpai_render_test_page'
        );
    }

    // Register all submenu pages
    foreach ($submenus as $submenu) {
        add_submenu_page(
            'wpai-dashboard',
            $submenu['page_title'],
            $submenu['menu_title'],
            $submenu['capability'],
            $submenu['menu_slug'],
            $submenu['function']
        );
    }
}

/**
 * Enqueue frontend scripts
 */
function wpai_enqueue_scripts() {
    wp_enqueue_style('wpai-styles', WPAI_PLUGIN_URL . 'assets/css/style.css', array(), WPAI_VERSION);
    wp_enqueue_script('wpai-script', WPAI_PLUGIN_URL . 'assets/js/ai-assistant.js', array('jquery'), WPAI_VERSION, true);
    
    // Add localization for AJAX
    wp_localize_script('wpai-script', 'wpai_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('wpai-nonce'),
        'initial_message' => get_option(WPAI_SETTINGS_KEY)['chat_initial_message']
    ));
}

/**
 * Enqueue admin scripts
 */
function wpai_admin_enqueue_scripts($hook) {
    if ('settings_page_wp-ai-assistant' !== $hook) {
        return;
    }
    
    wp_enqueue_style('wpai-admin-styles', WPAI_PLUGIN_URL . 'assets/css/admin.css', array(), WPAI_VERSION);
}

// Register hooks
register_activation_hook(__FILE__, 'wpai_activate');
add_action('plugins_loaded', 'wpai_init');
add_action('admin_menu', 'wpai_admin_menu');
add_action('wp_enqueue_scripts', 'wpai_enqueue_scripts');
add_action('admin_enqueue_scripts', 'wpai_admin_enqueue_scripts');
    private static $instance = null;

    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * Load required files
     */
    private function load_dependencies() {
        require_once WPAI_PLUGIN_DIR . 'includes/class-ai-chat.php';
        require_once WPAI_PLUGIN_DIR . 'includes/class-email-automation.php';
        require_once WPAI_PLUGIN_DIR . 'includes/class-customer-support.php';
        require_once WPAI_PLUGIN_DIR . 'includes/class-assistant-manager.php';
        require_once WPAI_PLUGIN_DIR . 'includes/class-assistant-validator.php';
        require_once WPAI_PLUGIN_DIR . 'includes/class-assistant-tester.php';
        require_once WPAI_PLUGIN_DIR . 'admin/admin-settings.php';
        require_once WPAI_PLUGIN_DIR . 'admin/admin-dashboard.php';
        require_once WPAI_PLUGIN_DIR . 'admin/create-assistant.php';
        require_once WPAI_PLUGIN_DIR . 'admin/test-system.php';
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_action('plugins_loaded', array($this, 'init'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
    }

    /**
     * Plugin activation
     */
    public function activate() {
        try {
            // Set default settings
            $default_settings = array(
                'openai_api_key' => '',
                'enable_chat' => true,
                'enable_email' => true,
                'enable_support' => true,
                'chat_initial_message' => 'Hi, My name is Berry',
                'model' => 'gpt-3.5-turbo'
            );
            
            if (!get_option(WPAI_SETTINGS_KEY)) {
                add_option(WPAI_SETTINGS_KEY, $default_settings);
            }

            // Create database tables
            $assistant_manager = WPAI_Assistant_Manager::get_instance();
            $assistant_manager->create_tables();
        } catch (Exception $e) {
            error_log('Berry AI Plugin Activation Error: ' . $e->getMessage());
            error_log('Error trace: ' . $e->getTraceAsString());
            wp_die('Error activating Berry AI plugin: ' . esc_html($e->getMessage()));
        }
    }
}

/**
 * Initialize the plugin
 */
if (!function_exists('wpai_init')) {
function wpai_init() {
    // Initialize the Assistant Manager first
    if (is_admin()) {
        WPAI_Assistant_Manager::get_instance();
    }

    // Initialize other classes
    new WPAI_Chat();
    new WPAI_Email_Automation();
    new WPAI_Customer_Support();
    
    // Add menu items
    if (is_admin()) {
        add_action('admin_menu', 'wpai_admin_menu');
        add_action('admin_init', 'wpai_register_settings');
    }
    
    // Enqueue scripts and styles
    }

    /**
     * Register admin menu
     */
    public function admin_menu() {

// Add admin menu items
if (!function_exists('wpai_admin_menu')) {
function wpai_admin_menu() {
    // Add main menu
    add_menu_page(
        'Berry AI Assistant',
        'Berry AI',
        'manage_options',
        'wpai-dashboard',
        'wpai_render_dashboard_page',
        'dashicons-superhero',
        30
    );

    // Add submenu pages
    $submenus = array(
        array(
            'page_title' => 'Dashboard',
            'menu_title' => 'Dashboard',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-dashboard',
            'function'   => 'wpai_render_dashboard_page'
        ),
        array(
            'page_title' => 'Create Assistant',
            'menu_title' => 'Create Assistant',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-create-assistant',
            'function'   => 'wpai_render_create_assistant_page'
        ),
        array(
            'page_title' => 'Settings',
            'menu_title' => 'Settings',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-settings',
            'function'   => 'wpai_render_settings_page'
        )
    );

    // Add system tests page if WP_DEBUG is enabled
    if (defined('WP_DEBUG') && WP_DEBUG) {
        $submenus[] = array(
            'page_title' => 'System Tests',
            'menu_title' => 'System Tests',
            'capability' => 'manage_options',
            'menu_slug'  => 'wpai-system-tests',
            'function'   => 'wpai_render_test_page'
        );
    }

    // Register all submenu pages
    foreach ($submenus as $submenu) {
        add_submenu_page(
            'wpai-dashboard',
            $submenu['page_title'],
            $submenu['menu_title'],
            $submenu['capability'],
            $submenu['menu_slug'],
            $submenu['function']
        );
    }
}
}

    /**
     * Initialize plugin
     */
    public function init() {
        // Initialize classes
        new WPAI_Chat();
        new WPAI_Email_Automation();
        new WPAI_Customer_Support();
    }

    /**
     * Register admin menu
     */
    public function admin_menu() {
        // Add main menu
        add_menu_page(
            'Berry AI Assistant',
            'Berry AI',
            'manage_options',
            'wpai-dashboard',
            'wpai_render_dashboard_page',
            'dashicons-superhero',
            30
        );

        // Add submenu pages
        $submenus = array(
            array(
                'page_title' => 'Dashboard',
                'menu_title' => 'Dashboard',
                'capability' => 'manage_options',
                'menu_slug'  => 'wpai-dashboard',
                'function'   => 'wpai_render_dashboard_page'
            ),
            array(
                'page_title' => 'Create Assistant',
                'menu_title' => 'Create Assistant',
                'capability' => 'manage_options',
                'menu_slug'  => 'wpai-create-assistant',
                'function'   => 'wpai_render_create_assistant_page'
            ),
            array(
                'page_title' => 'Settings',
                'menu_title' => 'Settings',
                'capability' => 'manage_options',
                'menu_slug'  => 'wpai-settings',
                'function'   => 'wpai_render_settings_page'
            )
        );

        // Add system tests page if WP_DEBUG is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $submenus[] = array(
                'page_title' => 'System Tests',
                'menu_title' => 'System Tests',
                'capability' => 'manage_options',
                'menu_slug'  => 'wpai-system-tests',
                'function'   => 'wpai_render_test_page'
            );
        }

        // Register all submenu pages
        foreach ($submenus as $submenu) {
            add_submenu_page(
                'wpai-dashboard',
                $submenu['page_title'],
                $submenu['menu_title'],
                $submenu['capability'],
                $submenu['menu_slug'],
                $submenu['function']
            );
        }
    }

    /**
     * Enqueue frontend scripts
     */
    public function enqueue_scripts() {
        wp_enqueue_style('wpai-styles', WPAI_PLUGIN_URL . 'assets/css/style.css', array(), WPAI_VERSION);
        wp_enqueue_script('wpai-script', WPAI_PLUGIN_URL . 'assets/js/ai-assistant.js', array('jquery'), WPAI_VERSION, true);
        
        // Add localization for AJAX
        wp_localize_script('wpai-script', 'wpai_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpai-nonce'),
            'initial_message' => get_option(WPAI_SETTINGS_KEY)['chat_initial_message']
        ));
    }

    /**
     * Enqueue admin scripts
     */
    public function admin_enqueue_scripts($hook) {
        if ('settings_page_wp-ai-assistant' !== $hook) {
            return;
        }
        
        wp_enqueue_style('wpai-admin-styles', WPAI_PLUGIN_URL . 'assets/css/admin.css', array(), WPAI_VERSION);
    }
}

// Initialize plugin
WPAI_Plugin::get_instance();
